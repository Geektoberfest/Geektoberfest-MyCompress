# MyCompress

MyCompress is a cross-platform command-line compressor that stores files and
directories in the `.mcz` archive format. The current built-in algorithm is
RLE, which is useful for simple data with repeated bytes.

## Download

Stable binaries are published on the [GitHub Releases](../../releases) page:

- Linux x86_64: `mycompress-<version>-linux-x86_64.tar.gz`
- Windows x86_64: `mycompress-<version>-windows-x86_64.zip`

macOS packages are not published yet.

Release archives contain one executable named `mycompress` on Linux or
`mycompress.exe` on Windows. No Rust installation is required to use a
release binary.

## Install

### Linux

```sh
tar -xzf mycompress-<version>-linux-x86_64.tar.gz
mkdir -p "$HOME/.local/bin"
install -m 755 mycompress "$HOME/.local/bin/mycompress"
export PATH="$HOME/.local/bin:$PATH"
```

Add the `export PATH=...` line to your shell profile to keep it after opening
a new terminal.

### Windows

Extract the ZIP file and move `mycompress.exe` to a permanent folder, such as
`C:\\Program Files\\MyCompress`. Add that folder to the user `PATH` through
**Settings > System > About > Advanced system settings > Environment
Variables**. Open a new terminal after changing `PATH`.

Verify the installation:

```text
mycompress --version
mycompress --help
```

## Usage

Compress a file or directory:

```text
mycompress compress ./photos -o ./photos.mcz
```

The output option is optional. Without `-o`, MyCompress writes the archive
next to the input using the input name with `.mcz` appended.

Inspect an archive without extracting it:

```text
mycompress info ./photos.mcz
mycompress list ./photos.mcz
```

Extract an archive:

```text
mycompress extract ./photos.mcz -d ./restored
```

Existing files are protected by default. Use `--force` only when overwriting
an existing archive or extracted file is intended.

Show all options:

```text
mycompress --help
mycompress compress --help
mycompress extract --help
```

## Build From Source

Building from source requires Rust 1.75 or newer:

```sh
git clone <repository-url>
cd MyCompress
cargo test --workspace
cargo build --release -p mycompress-cli
```

The resulting executable is `target/release/mycompress` or
`target/release/mycompress.exe`.

## Development

See [CONTRIBUTING.md](CONTRIBUTING.md), [docs/architecture.md](docs/architecture.md),
[docs/format.md](docs/format.md), and [docs/algorithms.md](docs/algorithms.md)
for project internals and contribution guidance.

## License

MyCompress is distributed under the MIT License. See [LICENSE](LICENSE).